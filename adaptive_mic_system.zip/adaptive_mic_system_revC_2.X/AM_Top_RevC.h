/* 
 * File:   Adaptive Microphone Top Level Header
 * Author: Andy Keech
 * Comments: Sr. Design - Tousi Group - EE4951W
 * Revision history: Revision A:    A. Keech    11/6/2020
 *                   Revision B:    A. Keech    11/14/2020    
 *                   Revision C:    A. Keech    11/21/2020
 * 
 */ 

#ifndef AM_TOP_REVC_H
#define	AM_TOP_REVC_H


#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */


// Assembly Library Function Declarations
    void delay_100us(void);
    void delay_1ms(void);                   
    void wait_1ms(void);
    
// Main Function Declarations
    void setup();
    
// Motor Library Function Declarations
    void delay(int delay_in_ms);            // Based on 1ms delay in assembly library
    void setResolution(int res);            
    void angleToSteps(double angle);
    void runCW(int steps);
    void runCCW(int steps);
      
// Sensor Array Library Function Declarations
    void wait_n_ms(int delay);     
    double Timing_calculation(void);

    
// LCD Library Function Declarations
    void lcd_cmd (char command);            
    void lcd_init(int contrast);
    void lcd_setCursor(char x, char y);     
    void lcd_printChar(char Package);
    void lcd_printStr(const char *s);
    void dly(int dly);              
    void wait_50ms(void);                   // Uses Timer 1
    void wait_200ms(void);                  


    
    
#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */