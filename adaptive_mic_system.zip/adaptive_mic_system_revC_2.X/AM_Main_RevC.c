/*
 * File:   AM_Main_RevC.c
 * Author: Ming Wu
 *
 * Created on November 21, 2020, 5:48 PM
 */


#include "xc.h"
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "AM_Top_RevC.h"



// PIC24FJ64GA002 Configuration Bit Settings
// CW1: FLASH CONFIGURATION WORD 1 (see PIC24 Family Reference Manual 24.1)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)


// CW2: FLASH CONFIGURATION WORD 2 (see PIC24 Family Reference Manual 24.1)
#pragma config POSCMOD = NONE      // Primary Oscillator Select (Primary oscillator disabled. 
                                   // Primary Oscillator refers to an external osc connected to the OSC1 and OSC2 pins)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // OSC2/CLKO/RC15 functions as port I/O (RC15)
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))



#define CONTRAST 0b01110111     // 0b10000000 (original contrast setting)
//char rotateAngle[4];
//double moveTo = 0;
//double numSteps=0;
//double curAngle;


void __attribute__((__interrupt__,__auto_psv__)) _T3Interrupt(void)
{
   
    _T3IF = 0;  
    
//    sprintf(rotateAngle, "%4.1f Deg", moveTo); // "x.xxxx V"
//            // 4.1 is the format string "%4.1f" means 4 placeholders for the whole
//            // Floating point number, 1 of which are for the fractional part.
//      lcd_setCursor(0,0);       // Set Cursor to top left
//      lcd_printStr(rotateAngle);      // Print most recent angle
  
}


int main(void) {
    
    setup();                            // HW and Timer Setup
    lcd_init(CONTRAST);                 // LCD initialzation
    dly(32000);                         //~2ms required after init
    setResolution(1);
    
    
    while(1)
    {  
//        moveTo = 360;
//       
//            numSteps = angleToSteps(moveTo);
//            runCW(numSteps);
//            delay(1000);        //delay 1sec
//            
//            moveTo = 360;
//            numSteps = angleToSteps(moveTo);
//            runCCW(numSteps);
//            delay(1000);
        
//        wait_200ms();
        PORTAbits.RA0 ^=1;              // Simple heartbeat LED to ensure while loop is running
       
        
    }
    return 0;
}