/*
 * File:   AM_Setup_RevC.c
 * Author: andy k & ming w
 *
 * Created on November 21, 2020, 5:45 PM
 */


#include "xc.h"
#include "AM_Top_RevC.h"

void setup()
{
    /*General HW Setup*/
    CLKDIVbits.RCDIV = 0;       // Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M
    AD1PCFG = 0x9fff;           // Set all pins to digital
    TRISB = 0;                  // Set PORTB<15:0> to 0000 0000 0000 0000 
    TRISA = 0;                  // Set PORTA<15:0> to 0000 0000 0000 0000 (all outputs) 
    TRISB |= 0x0070;                // Set PORTB<15:0> to 0000 0000 0111 0000
    
    // Sound Detector Sensor Pins
    // RB4: IC1
    // RB5: IC2
    // RB6: IC3
    // EasyDriver Pins
    // RB10: Step
    // RB11: Direction
    // RB12: MS1
    // RB13: MS2
    // RB14: Enable
    
    
    /*Timer 1 Setup - For delay functions in both assembly and C libraries; including 50ms delay, 100ms delay, and more. */
    T1CON = 0;                  // T1 16 bit timer setup: T1 off, prescale 1:1, internal clock
    PR1= 11499;                 // Setting PR1 for 50ms timer 1
    TMR1 = 0;                   // Reset T1 counter
    //_T2IE = 1;                //enable interrupt
    _T1IF = 0;                  // Reset T1 interrupt flag
    T1CON = 0x8020;             // Timer 1 on (bit 15), 1:64 prescaler,
       
    /* Timer 2 Setup - For logging audio events and calculating time difference between sensors.  Period = 4ms = 0.004s */
    T2CON |= 0x0000;            //Stop Timer, Tcy clk source, PRE 1:1
    TMR2 = 0;                   // Initialize to zero
    PR2 = 65535; 
    _T2IF = 0;                  //clear interrupt flag
    _T2IE = 1;                  //enable interrupt
    T2CONbits.TON = 1;          // Restart 16-bit Timer2
    
    /*Timer 3 Setup - For Updating LCD. Period = 100ms*/
    T3CON = 0;
    PR3 = 6250;
    TMR3 = 0;
    _T3IF = 0;
    T3CON = 0x8030;             // Timer 3 on (bit 15), 1:256 prescaler for 100ms)
    _T3IE = 1;
    
    /*I2C2 setup*/
    I2C2CONbits.I2CEN = 0;      // Good practice to disable I2C2 peripheral before changing BRG
    I2C2BRG = 0x9D;             // Setting I2C2 baud rate generator to 100 kHz
    I2C2CONbits.I2CEN = 1;      // Enables the I2C2 module and configures the SDA2 and SCL2 pins 
                                // (pins 6 and 7, respectively), as serial port pins
    IFS3bits.MI2C2IF = 0;       // Clearing I2C2 interrupt flag to be safe
    
    // Sensor Array/Input Capture Setup
    __builtin_write_OSCCONL(OSCCON & 0xbf); // unlock PPS
    RPINR7bits.IC1R = 4;  // Use Pin RP4 = "4", for Input Capture 1 
    RPINR7bits.IC2R = 5;  // Use Pin RP5 for Input Capture 2
    RPINR8bits.IC3R = 6;  // Use Pin RP6 for IC 3
    RPINR8bits.IC4R = 7;  
    __builtin_write_OSCCONL(OSCCON | 0x40); // lock   PPS
    
    
    IC1CON = 0; // Turn off and reset internal state of IC1
    IC1CONbits.ICTMR = 1; // Use Timer 2 for capture source
    IC1CON = 1; // Interrupt on every capture event
    IC1CONbits.ICM = 0b011; // Turn on and capture every rising edge
    _IC1IE = 1; // Enable IC1 interrupts
    
    IC2CON = 0; // Turn off and reset internal state of IC2
    IC2CONbits.ICTMR = 1; // Use Timer 2 for capture source
    IC2CON = 1; // Interrupt on every capture event
    IC2CONbits.ICM = 0b011; // Turn on and capture every rising edge
    _IC2IE = 1; // Enable IC2 interrupts
    
    IC3CON = 0; // Turn off and reset internal state of IC3
    IC3CONbits.ICTMR = 1; // Use Timer 2 for capture source
    IC3CON = 1; // Interrupt on every capture event
    IC3CONbits.ICM = 0b011; // Turn on and capture every rising edge
    _IC3IE = 1; // Enable IC3 interrupts
    
    IC4CON = 0; // Turn off and reset internal state of IC4
    IC4CONbits.ICTMR = 1; // Use Timer 2 for capture source
    IC4CON = 1; // Interrupt on every capture event
    IC4CONbits.ICM = 0b011; // Turn on and capture every rising edge
   _IC4IE = 1; // Enable IC4 interrupts
    
}
    
