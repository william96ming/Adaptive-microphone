/*
 * File:   AM_SensorArray_Lib_RevC.c
 * Author: ming wu
 *
 * Created on November 21, 2020, 8:37 PM
 */


#include "xc.h"
#include <stdint.h>
#include <math.h>
#include <stdio.h>
#include <assert.h>
#include "AM_Top_RevC.h"

#define abs(x) (x<0?-x:x)

//volatile int rollover = 0;
int rollover = 0;
int count=0;
int count1=0;
int count2=0;
int count3=0;
int count4 =0;
long long int curTime_1 =0;
long long int curTime_2 =0;
long long int curTime_3 =0;
long long int curTime_4 =0;
double angle,angle_pervious = 0;
int rotate;          // TRY VOLATILE INT OR FLOAT
double test = -90;

// For LCD display in timing calculation
double numSteps=0;
char rotateAngle[4];
double moveTo = 0;

void wait_n_ms(int delay){
    int i= delay;
    for(;i>0;i--){
        
        wait_1ms();
    }
}

//Timer interrupt
void __attribute__((interrupt, auto_psv)) _T2Interrupt(){      

    rollover++;
    _T2IF = 0;             //clear interrupt flag

}

//IC1
void __attribute__ ((interrupt, auto_psv)) _IC1Interrupt()
{
    
    curTime_1 = (TMR2 + (rollover * 65536));
    count1=1;
    
    if(count2 == 1){
        if(abs(curTime_1 - curTime_2) > 15000){
            count2 = 0;
        }
    }
    
    if(count3 == 1){
        if(abs(curTime_1 - curTime_3) > 15000){
            count3 = 0;
        }
    }
    
    if(count4 == 1){
        if(abs(curTime_1 - curTime_4) > 15000){
            count4 = 0;
        }
    }
    
    if ((count1 == 1)&&(count2 == 1)&&(count3 == 1)&&(count4 == 1)){
        Timing_calculation();
        count1= 0;
        count2=0;
        count3=0;
        count4=0;
    }
    _IC1IF = 0; 

}

//IC 2
void __attribute__ ((interrupt, auto_psv)) _IC2Interrupt(){
    
    curTime_2 = TMR2 + (rollover * 65536);
    count2=1;
    
    if(count1 == 1){
        if(abs(curTime_2 - curTime_1) > 15000){
            count1 = 0;
        }
    }
    
    if(count3 == 1){
        if(abs(curTime_2 - curTime_3) > 15000){
            count3 = 0;
        }
    }
    
    if(count4 == 1){
        if(abs(curTime_2 - curTime_4) > 15000){
            count4 = 0;
        }
    }
    
    if ((count1 == 1)&&(count2 == 1)&&(count3 == 1)&&(count4 == 1)){
        Timing_calculation();
        count1= 0;
        count2=0;
        count3=0;
        count4=0;
    }
    _IC2IF = 0;

}

//IC3
void __attribute__ ((interrupt, auto_psv)) _IC3Interrupt(){
    
    curTime_3 = TMR2 + (rollover * 65536);
    count3=1;
    
    if(count1 == 1){
        if(abs(curTime_3 - curTime_1) > 15000){
            count1 = 0;
        }
    }
    
    if(count2 == 1){
        if(abs(curTime_3 - curTime_2) > 15000){
            count2 = 0;
        }
    }
    
    if(count4 == 1){
        if(abs(curTime_3 - curTime_4) > 15000){
            count4 = 0;
        }
    }
    
    if ((count1 == 1)&&(count2 == 1)&&(count3 == 1)&&(count4 == 1)){
        Timing_calculation();
        count1= 0;
        count2=0;
        count3=0;
        count4=0;
    }
    _IC3IF = 0;

}

//IC4
void __attribute__ ((interrupt, auto_psv)) _IC4Interrupt(){
    
    curTime_4 = TMR2 + (rollover * 65536);
    count4=1;
    
    if(count1 == 1){
        if(abs(curTime_4 - curTime_1) > 15000){
            count1 = 0;
        }
    }
    
    if(count2 == 1){
        if(abs(curTime_4 - curTime_2) > 15000){
            count2 = 0;
        }
    }
    
    if(count3 == 1){
        if(abs(curTime_4 - curTime_3) > 15000){
            count3 = 0;
        }
    }
    
    if ((count1 == 1)&&(count2 == 1)&&(count3 == 1)&&(count4 == 1)){
        Timing_calculation();
        count1= 0;
        count2=0;
        count3=0;
        count4=0;
    }
    _IC4IF = 0;

}

double Timing_calculation(){
    
    double X_test,Y_test;
    double distant_1,distant_2,distant_3,distant_4;
    double D1_square,D2_square,D3_square,D4_square;
    double distant_diff_12,distant_diff_23,distant_diff_13,distant_diff_14,distant_diff_24;
    long int Timediff_12,Timediff_23,Timediff_13,Timediff_14,Timediff_24;
    double x,y;
    long sum = 0,sum_mini;
    
    X_test=-30;
    Y_test=-30;
    x=0,y=0;
    sum_mini = 1000000;
    //**Get Time difference**
    
    Timediff_12 = curTime_1 - curTime_2;
    Timediff_23 = curTime_2 - curTime_3;
    Timediff_13 = curTime_1 - curTime_3;
    Timediff_14 = curTime_1 - curTime_4;
    Timediff_24 = curTime_2 - curTime_4;
    
    
    //The unit of X,Y is 15 cm
    //Test from (-30,-30) to (30,30)
    while(Y_test <31)
    {
        
         //when finish test X from -30 to 30, Y++
        if(X_test ==30)
        {
            X_test = -30;
            Y_test++;
        }
        
        
        //**calculate the distant from sound source to sensors**
        
        D1_square = (X_test * X_test) + (Y_test * Y_test);
        distant_1 = sqrt(D1_square);
        
        D2_square = ((X_test + 1)*(X_test +1)) + (Y_test * Y_test);
        distant_2 = sqrt(D2_square);
        
        D3_square = ((X_test +1)*(X_test +1)) + ((Y_test+1)*(Y_test+1));
        distant_3 = sqrt(D3_square);
        
        D4_square = ((X_test)*(X_test)) + ((Y_test+1)*(Y_test+1));
        distant_4 = sqrt(D4_square);
        
        
        //**find the distance difference**
        
        distant_diff_12 = distant_1 - distant_2;
        distant_diff_23 = distant_2 - distant_3;
        distant_diff_13 = distant_1 - distant_3;
        distant_diff_14 = distant_1 - distant_4;
       distant_diff_24 = distant_2 - distant_4;
        //Until now,we have time differences(TD) and distance differences(DD)
        
        
        //**Find the location of sound**
        
        //based on the speed of sound, 15 cm will have 7059 unit difference in Timer 2
        //find the absolute values of the difference between TD & DD, add three of them together to get the sum
        
        sum = abs((distant_diff_12 * 7059 - Timediff_12)) + abs((distant_diff_23 * 7059 - Timediff_23)) + abs((distant_diff_13 * 7059 - Timediff_13 ))+ abs((distant_diff_14 * 7059 - Timediff_14)) + abs((distant_diff_24 * 7059 - Timediff_13));
        
        //When the sum is smallest, we assume this location of sound
        //Anytime find a smaller sum,
        //store this (x,y) to x,y and sum to sum_mini
        
        if (sum < sum_mini)
        {
            x = X_test;
            y = Y_test;
            sum_mini = sum;
        }
        
        X_test++;
        
        }//End of find location "if" loop
    
    
    //**transfer location value to angle value**
    
    angle = atan (y/x) *180/3.1415;
    
    //based on the sign of x & y, modify the angle value (just math stuff)
    if(x < 0){
        angle = 180 + angle;
    }if( (x >= 0) && (y < 0) ){
        angle = angle + 360;
    }
    
    
    //**Determine the rotation of motor**
    
    //to avoid fluctuation of motor
    //ignore the value when the change of angle less than 5 degree
    //so the microphone working more stable 
    
    rotate = angle - angle_pervious;
    angle_pervious = angle;
    
//    if (abs(rotate) < 5){
//        
//        rotate = 0;
//        
//    }



    
    angleToSteps(rotate);
//    runCW(numSteps);
    sprintf(rotateAngle, "%4.1f Deg", angle); // "x.xxxx V"
            // 4.1 is the format string "%4.1f" means 4 placeholders for the whole
            // Floating point number, 1 of which are for the fractional part.
      lcd_setCursor(0,0);       // Set Cursor to top left
      lcd_printStr(rotateAngle);      // Print most recent angle
    delay(1000);        //delay 1sec
    numSteps = 0;
//    _IC1IF = 0;
//    _IC2IF = 0;
//    _IC3IF = 0;
    
    //At this point, we have the rotate/nextAngle value of motor

    return 0;
}
